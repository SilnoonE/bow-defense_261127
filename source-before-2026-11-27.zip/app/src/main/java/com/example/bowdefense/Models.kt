package com.example.bowdefense

import android.graphics.RectF
import kotlin.math.*

/**
 * 게임의 주요 엔티티(Entity)들을 정의하는 파일입니다.
 */

// 화살 객체
data class Arrow(
    var x: Float,
    var y: Float,
    val angle: Float, // 발사 각도
    val speed: Float, // 화살 속도
    val damage: Int   // 공격력
) {
    // 충돌 판정을 위한 사각형 범위
    // 화살이 회전하므로, 화살의 '머리(Tip)' 부분의 실제 좌표를 계산하여 판정합니다.
    fun getBounds(): RectF {
        val rad = Math.toRadians(angle.toDouble())
        // 화살 길이가 100이므로, x,y(꼬리)에서 100만큼 떨어진 지점이 머리입니다.
        val tipX = x + (100f * cos(rad)).toFloat()
        val tipY = y + (100f * sin(rad)).toFloat()
        
        // 화살촉 주변 아주 작은 범위(20x20)만 판정으로 잡아 정교함을 높입니다.
        val hitSize = 20f
        return RectF(tipX - hitSize, tipY - hitSize, tipX + hitSize, tipY + hitSize)
    }

    // 매 프레임 위치 업데이트
    fun update() {
        val rad = Math.toRadians(angle.toDouble())
        x += (speed * cos(rad)).toFloat()
        y += (speed * sin(rad)).toFloat()
    }
}

// 몬스터 객체
data class Monster(
    var x: Float,
    var y: Float,
    var hp: Int,
    val speed: Float,
    val type: Config.MonsterType,
    val scoreValue: Int
) {
    // 몬스터 이미지 중앙을 기준으로 Config에 설정된 HITBOX 크기만큼 판정 범위를 잡습니다.
    fun getBounds(): RectF {
        val isTank = type == Config.MonsterType.TANK
        val sizeMultiplier = if (isTank) 1.4f else 1.0f
        
        val renderSize = Config.MONSTER_RENDER_SIZE * sizeMultiplier
        val hitboxSize = Config.MONSTER_HITBOX_SIZE * sizeMultiplier
        
        // 이미지의 정중앙 좌표 계산
        val centerX = x + renderSize / 2f
        val centerY = y + renderSize / 2f
        
        // 중앙에서 hitboxSize의 절반만큼 사방으로 펼침
        return RectF(
            centerX - hitboxSize / 2f,
            centerY - hitboxSize / 2f,
            centerX + hitboxSize / 2f,
            centerY + hitboxSize / 2f
        )
    }

    // 왼쪽(방어선)으로 이동
    fun update() {
        x -= speed
    }

    fun updateSlowed() {
        x -= speed * 0.5f
    }

    // 데미지를 받음
    fun takeDamage(amount: Int) {
        hp -= amount
    }

    fun isDead(): Boolean = hp <= 0
}

// 플레이어(성벽/궁수) 상태 데이터
data class Player(
    var hp: Int = Config.PLAYER_MAX_HP,
    var currentDamage: Int = Config.BASE_ARROW_DAMAGE,
    var fireCooldown: Long = Config.BASE_FIRE_COOLDOWN,
    var arrowSpeed: Float = Config.BASE_ARROW_SPEED,
    var kills: Int = 0,
    var lastFireTime: Long = 0
) {
    fun canFire(): Boolean {
        return System.currentTimeMillis() - lastFireTime >= fireCooldown
    }

    fun resetFireTime() {
        lastFireTime = System.currentTimeMillis()
    }
}
