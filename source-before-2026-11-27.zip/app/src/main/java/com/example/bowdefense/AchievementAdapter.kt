package com.example.bowdefense

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AchievementAdapter(private var achievements: List<Achievement>) :
    RecyclerView.Adapter<AchievementAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameText: TextView = view.findViewById(R.id.achievementName)
        val descText: TextView = view.findViewById(R.id.achievementDesc)
        val rewardText: TextView = view.findViewById(R.id.achievementReward)
        val root: View = view
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_achievement, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val ach = achievements[position]
        val context = holder.itemView.context
        
        val nameResId = context.resources.getIdentifier("achievement_name_${ach.id}", "string", context.packageName)
        val descResId = context.resources.getIdentifier("achievement_desc_${ach.id}", "string", context.packageName)
        
        holder.nameText.text = if (nameResId != 0) context.getString(nameResId) else ach.name
        holder.descText.text = if (descResId != 0) context.getString(descResId) else ach.description
        holder.rewardText.text = "+${ach.rewardGold}G"

        if (ach.isUnlocked) {
            holder.root.alpha = 1.0f
            holder.nameText.setTextColor(Color.WHITE)
            holder.descText.setTextColor(0xFFBDBDBD.toInt())
        } else {
            holder.root.alpha = 0.5f
            holder.nameText.setTextColor(Color.GRAY)
            holder.descText.setTextColor(Color.GRAY)
        }
    }

    override fun getItemCount() = achievements.size

    fun updateData(newAchievements: List<Achievement>) {
        achievements = newAchievements
        notifyDataSetChanged()
    }
}
