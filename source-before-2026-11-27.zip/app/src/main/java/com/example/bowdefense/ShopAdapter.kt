package com.example.bowdefense

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.bowdefense.R

class ShopAdapter(
    private var items: List<ShopBowItem>,
    private val onActionClick: (ShopBowItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class BowViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameText: TextView = view.findViewById(R.id.bowNameText)
        val effectText: TextView = view.findViewById(R.id.bowEffectText)
        val priceText: TextView = view.findViewById(R.id.bowPriceText)
        val actionButton: Button = view.findViewById(R.id.buyButton)
        val bowImage: ImageView = view.findViewById(R.id.bowImageView)
    }

    class DividerViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titleText: TextView = view.findViewById(R.id.dividerTitle)
    }

    override fun getItemViewType(position: Int): Int {
        return items[position].itemType
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            ShopBowItem.TYPE_DIVIDER -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shop_divider, parent, false)
                DividerViewHolder(view)
            }
            else -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_shop_bow, parent, false)
                BowViewHolder(view)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        
        if (holder is DividerViewHolder) {
            holder.titleText.text = item.displayName
            return
        }

        if (holder is BowViewHolder) {
            holder.nameText.text = item.displayName
            holder.effectText.text = item.effectText
            
            // 이미지 매핑
            val resId = when(item.productId) {
                "high_bow" -> R.drawable.high_bow
                "basic_bow_5" -> R.drawable.basic_bow_5
                "basic_bow_4" -> R.drawable.basic_bow_4
                "basic_bow_3" -> R.drawable.basic_bow_3
                "basic_bow_2" -> R.drawable.basic_bow_2
                "basic_bow" -> R.drawable.basic_bow
                "bow" -> R.drawable.bow
                "life_5" -> android.R.drawable.ic_menu_add
                "item_potion" -> R.drawable.ic_potion
                "item_power" -> R.drawable.ic_power_arrow
                "item_slow" -> R.drawable.ic_slow_stone
                else -> R.drawable.bow
            }
            holder.bowImage.setImageResource(resId)

            // 버튼 상태 및 텍스트 설정
            when {
                item.itemType == ShopBowItem.TYPE_BATTLE_ITEM -> {
                    holder.priceText.text = context.getString(R.string.battle_item_count, item.priceText, item.count)
                    holder.actionButton.text = context.getString(R.string.buy)
                    holder.actionButton.isEnabled = true
                    holder.actionButton.alpha = 1.0f
                }
                item.itemType == ShopBowItem.TYPE_ITEM -> {
                    holder.priceText.text = item.priceText
                    holder.actionButton.text = context.getString(R.string.buy)
                    holder.actionButton.isEnabled = true
                    holder.actionButton.alpha = 1.0f
                }
                item.isEquipped -> {
                    holder.priceText.text = context.getString(R.string.currently_using)
                    holder.actionButton.text = context.getString(R.string.selecting)
                    holder.actionButton.isEnabled = false
                    holder.actionButton.alpha = 0.5f
                }
                item.isOwned -> {
                    holder.priceText.text = context.getString(R.string.owned)
                    holder.actionButton.text = context.getString(R.string.equip)
                    holder.actionButton.isEnabled = true
                    holder.actionButton.alpha = 1.0f
                }
                else -> {
                    holder.priceText.text = item.priceText
                    holder.actionButton.text = context.getString(R.string.buy)
                    holder.actionButton.isEnabled = true
                    holder.actionButton.alpha = 1.0f
                }
            }

            holder.actionButton.setOnClickListener { onActionClick(item) }
        }
    }

    override fun getItemCount() = items.size

    fun updateItems(newItems: List<ShopBowItem>) {
        this.items = newItems
        notifyDataSetChanged()
    }
}
