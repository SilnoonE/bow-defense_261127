package com.example.bowdefense

import android.content.Context

/**
 * 기존 매니저 클래스들과의 호환성을 위해 유지하며, 데이터는 PurchaseStore에서 총괄합니다.
 */
class SaveManager(context: Context) {
    private val store = PurchaseStore(context)
    fun saveHighScore(score: Int) = store.saveHighScore(score)
    fun getHighScore(): Int = store.getHighScore()
}

class LifeManager(context: Context) {
    private val store = PurchaseStore(context)
    fun getLifeCount(): Int = store.getLifeCount()
    fun addLives(count: Int) = store.addLives(count)
    fun useLife(): Boolean {
        val current = getLifeCount()
        if (current > 0) {
            store.addLives(-1)
            return true
        }
        return false
    }
}

class UpgradeManager {
    var totalKills = 0 
    var cumulativeKills = 0 
    var monstersSpawned = 0 // 웨이브당 스폰량 추적용 추가
}

class StageManager {
    var currentStage = 1
    var currentWave = 1
    var monstersSpawned = 0
    var monstersKilled = 0

    fun sync(stage: Int, wave: Int) {
        currentStage = stage
        currentWave = wave
        monstersSpawned = 0
        monstersKilled = 0
    }

    fun nextWave() {
        currentWave++
        if (currentWave > 3) {
            currentStage++
            currentWave = 1
        }
        monstersSpawned = 0
        monstersKilled = 0
    }
}

object GameSessionManager {
    var hasContinuedThisGame = false 
    fun reset() { hasContinuedThisGame = false }
}
