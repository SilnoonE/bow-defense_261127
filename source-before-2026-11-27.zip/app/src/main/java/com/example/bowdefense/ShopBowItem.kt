package com.example.bowdefense

/**
 * 상점에서 상품의 상태를 관리하는 데이터 클래스입니다.
 */
data class ShopBowItem(
    val productId: String,
    val displayName: String,
    var priceText: String = "가격 확인 중",
    var effectText: String = "",
    var isOwned: Boolean = false,
    var isEquipped: Boolean = false,
    var itemType: Int = TYPE_BOW, // 0: 활, 1: 아이템(생명), 2: 구분선, 3: 배틀 아이템
    var count: Int = 0,
    var goldPrice: Int = 0
) {
    companion object {
        const val TYPE_BOW = 0
        const val TYPE_ITEM = 1
        const val TYPE_DIVIDER = 2
        const val TYPE_BATTLE_ITEM = 3
    }
}
