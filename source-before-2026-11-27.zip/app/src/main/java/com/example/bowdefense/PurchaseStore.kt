package com.example.bowdefense

import android.content.Context
import android.content.SharedPreferences

/**
 * 모든 영구 데이터(구매 내역, 장착 상태, 점수, 생명)를 관리하는 통합 클래스입니다.
 */
class PurchaseStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("BowDefensePrefs", Context.MODE_PRIVATE)

    // 최고 점수 관리
    fun saveHighScore(score: Int) {
        val currentHigh = getHighScore()
        if (score > currentHigh) {
            prefs.edit().putInt("high_score", score).apply()
        }
    }
    fun getHighScore(): Int = prefs.getInt("high_score", 0)

    // 골드 관리
    fun getGold(): Int = prefs.getInt("total_gold", 0)
    fun addGold(amount: Int) {
        prefs.edit().putInt("total_gold", getGold() + amount).apply()
    }

    // 아이템 수량 관리
    fun getItemCount(itemId: String): Int = prefs.getInt("item_$itemId", 0)
    fun addItem(itemId: String, count: Int) {
        val current = getItemCount(itemId)
        prefs.edit().putInt("item_$itemId", (current + count).coerceIn(0, 10)).apply()
    }
    fun useItem(itemId: String): Boolean {
        val current = getItemCount(itemId)
        if (current > 0) {
            prefs.edit().putInt("item_$itemId", current - 1).apply()
            return true
        }
        return false
    }

    // 아이템 통계
    fun incrementItemStat(statKey: String) {
        val current = prefs.getInt(statKey, 0)
        prefs.edit().putInt(statKey, current + 1).apply()
    }
    fun getItemStat(statKey: String): Int = prefs.getInt(statKey, 0)

    // 생명(이어하기 아이템) 관리
    fun getLifeCount(): Int = prefs.getInt("life_count", 0)
    fun addLives(count: Int) {
        prefs.edit().putInt("life_count", getLifeCount() + count).apply()
    }

    // 스킨 소유 여부 관리
    fun isOwned(productId: String): Boolean {
        if (productId == "bow") return true // 기본 활은 항상 소유
        return prefs.getBoolean("owned_$productId", false)
    }
    fun setOwned(productId: String, owned: Boolean) {
        prefs.edit().putBoolean("owned_$productId", owned).apply()
    }

    // 현재 장착된 활 ID 가져오기 (기본값: bow)
    fun getEquippedBow(): String {
        return prefs.getString("equipped_bow", "bow") ?: "bow"
    }

    // 활 장착 상태 저장
    fun setEquippedBow(productId: String) {
        prefs.edit().putString("equipped_bow", productId).apply()
    }

    // 설정 관리
    fun isBgmEnabled(): Boolean = prefs.getBoolean("bgm_enabled", true)
    fun setBgmEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("bgm_enabled", enabled).apply()
    }
    fun isVibrationEnabled(): Boolean = prefs.getBoolean("vibration_enabled", true)
    fun setVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("vibration_enabled", enabled).apply()
    }
}
