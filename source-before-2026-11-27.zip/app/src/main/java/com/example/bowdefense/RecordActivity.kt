package com.example.bowdefense

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class RecordActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        val summaryDetails = findViewById<TextView>(R.id.summaryDetails)
        val recordsList = findViewById<LinearLayout>(R.id.recordsList)

        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(this@RecordActivity)
            val dao = db.gameDao()
            val stats = dao.getPlayerStats() ?: PlayerStats()
            
            val avgAccuracy = if (stats.totalArrowsShot > 0) (stats.totalHitCount.toFloat() / stats.totalArrowsShot) * 100 else 0f
            
            val summaryText = """
                ${getString(R.string.summary_best_score, stats.maxScore)}
                ${getString(R.string.summary_best_survival, stats.totalSurvivalTime)}
                ${getString(R.string.summary_play_count, stats.totalPlayCount)}
                ${getString(R.string.summary_total_kills, stats.totalKills)}
                ${getString(R.string.summary_avg_accuracy, avgAccuracy.toInt())}
                ${getString(R.string.summary_best_stage, stats.maxStage, stats.maxWave)}
                ${getString(R.string.summary_total_gold, stats.totalGoldEarned)}
            """.trimIndent()
            
            runOnUiThread { summaryDetails.text = summaryText }

            val recentRecords = dao.getRecentRecords().first()
            runOnUiThread {
                recordsList.removeAllViews()
                if (recentRecords.isEmpty()) {
                    val tv = TextView(this@RecordActivity)
                    tv.text = getString(R.string.no_records)
                    tv.setTextColor(0xFFFFFFFF.toInt())
                    tv.setPadding(0, 50, 0, 0)
                    tv.gravity = android.view.Gravity.CENTER
                    recordsList.addView(tv)
                } else {
                    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                    recentRecords.forEach { record ->
                        val view = LayoutInflater.from(this@RecordActivity).inflate(R.layout.item_record, recordsList, false)
                        view.findViewById<TextView>(R.id.recordDate).text = sdf.format(Date(record.playDate))
                        view.findViewById<TextView>(R.id.recordScore).text = "${getString(R.string.score_label, record.score)}"
                        view.findViewById<TextView>(R.id.recordStage).text = "Stage ${record.maxStage}-${record.maxWave}"
                        view.findViewById<TextView>(R.id.recordStats).text = "${record.survivalTimeSeconds}s | ${record.killCount} Kills | ${String.format(Locale.getDefault(), "%.1f", record.accuracy)}%"
                        recordsList.addView(view)
                    }
                }
            }
        }
    }
}
