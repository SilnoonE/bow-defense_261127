package com.example.bowdefense

import android.app.Activity
import android.util.Log
import android.widget.Toast
import com.android.billingclient.api.*

class BillingManager(private val activity: Activity, private val purchaseStore: PurchaseStore) {

    private val billingClient: BillingClient = BillingClient.newBuilder(activity)
        .setListener { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (purchase in purchases) {
                    handlePurchase(purchase)
                }
            }
        }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    private val productDetailsMap = mutableMapOf<String, ProductDetails>()
    var onDetailsLoaded: (() -> Unit)? = null
    var onPurchaseSuccess: ((String) -> Unit)? = null

    init {
        startConnection()
    }

    fun startConnection() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    restorePurchases()
                }
            }
            override fun onBillingServiceDisconnected() {
                Log.e("Billing", "Service Disconnected")
            }
        })
    }

    private fun queryProducts() {
        val ids = listOf("high_bow", "basic_bow_5", "basic_bow_4", "basic_bow_3", "basic_bow_2", "basic_bow", "life_5")
        val productList = ids.map { 
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.INAPP)
                .build() 
        }

        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
        billingClient.queryProductDetailsAsync(params) { billingResult, queryProductDetailsResult ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                queryProductDetailsResult.productDetailsList?.forEach { productDetailsMap[it.productId] = it }
                onDetailsLoaded?.invoke()
            }
        }
    }

    fun launchPurchaseFlow(productId: String) {
        val productDetails = productDetailsMap[productId]
        if (productDetails == null) {
            Toast.makeText(activity, activity.getString(R.string.billing_loading), Toast.LENGTH_SHORT).show()
            queryProducts()
            return
        }
        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(
                BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(productDetails)
                    .build()
            ))
            .build()
        billingClient.launchBillingFlow(activity, flowParams)
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged) {
                val params = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient.acknowledgePurchase(params) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        purchase.products.forEach { productId ->
                            if (productId == "life_5") {
                                purchaseStore.addLives(5)
                            } else {
                                purchaseStore.setOwned(productId, true)
                            }
                            onPurchaseSuccess?.invoke(productId)
                        }
                    }
                }
            }
        }
    }

    fun restorePurchases() {
        billingClient.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        ) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { purchase ->
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        purchase.products.forEach { productId ->
                            if (productId != "life_5") purchaseStore.setOwned(productId, true)
                        }
                    }
                }
                onDetailsLoaded?.invoke()
            }
        }
    }

    fun getPrice(productId: String): String = 
        productDetailsMap[productId]?.oneTimePurchaseOfferDetails?.formattedPrice ?: activity.getString(R.string.price_checking)
}
