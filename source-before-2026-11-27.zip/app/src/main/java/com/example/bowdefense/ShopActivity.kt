package com.example.bowdefense

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class ShopActivity : BaseActivity() {

    private lateinit var purchaseStore: PurchaseStore
    private lateinit var billingManager: BillingManager
    private lateinit var dataManager: DataManager
    private lateinit var adapter: ShopAdapter
    private lateinit var inventoryStatusText: TextView
    private lateinit var goldText: TextView
    
    private val shopItems = mutableListOf<ShopBowItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)

        purchaseStore = PurchaseStore(this)
        dataManager = DataManager(this)
        inventoryStatusText = findViewById(R.id.inventoryStatusText)
        goldText = findViewById(R.id.goldText)
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        initShopItems()

        val recyclerView = findViewById<RecyclerView>(R.id.shopRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ShopAdapter(shopItems) { item ->
            handleItemAction(item)
        }
        recyclerView.adapter = adapter

        billingManager = BillingManager(this, purchaseStore)
        
        billingManager.onDetailsLoaded = {
            runOnUiThread { updateUI() }
        }
        
        billingManager.onPurchaseSuccess = { productId ->
            lifecycleScope.launch {
                val db = AppDatabase.getDatabase(this@ShopActivity)
                val stats = db.gameDao().getPlayerStats() ?: PlayerStats()
                stats.totalShopPurchases++
                db.gameDao().updatePlayerStats(stats)
            }

            runOnUiThread {
                val itemName = shopItems.find { it.productId == productId }?.displayName ?: ""
                Toast.makeText(this, getString(R.string.purchase_complete, itemName), Toast.LENGTH_SHORT).show()
                updateUI()
            }
        }
    }

    private fun initShopItems() {
        shopItems.clear()
        
        // 1. 아이템 섹션 (생명 등)
        shopItems.add(ShopBowItem("div_item", getString(R.string.item_section), itemType = ShopBowItem.TYPE_DIVIDER))
        shopItems.add(ShopBowItem("life_5", getString(R.string.life_recharge), effectText = getString(R.string.life_recharge_desc), itemType = ShopBowItem.TYPE_ITEM))

        // 2. 활 섹션
        shopItems.add(ShopBowItem("div_bow", getString(R.string.bow_section), itemType = ShopBowItem.TYPE_DIVIDER))
        
        // 기본 활 (무료)
        shopItems.add(ShopBowItem("bow", getString(R.string.bow_default_name), "0G", getString(R.string.bow_default_desc), isOwned = true, itemType = ShopBowItem.TYPE_BOW))
        
        // 일반 유료 활들 (공격속도 20% 보너스)
        shopItems.add(ShopBowItem("basic_bow_5", getString(R.string.bow_ruby_name), effectText = getString(R.string.bow_bonus_20), itemType = ShopBowItem.TYPE_BOW))
        shopItems.add(ShopBowItem("basic_bow_4", getString(R.string.bow_frost_name), effectText = getString(R.string.bow_bonus_20), itemType = ShopBowItem.TYPE_BOW))
        shopItems.add(ShopBowItem("basic_bow_3", getString(R.string.bow_venom_name), effectText = getString(R.string.bow_bonus_20), itemType = ShopBowItem.TYPE_BOW))
        shopItems.add(ShopBowItem("basic_bow_2", getString(R.string.bow_seraphic_name), effectText = getString(R.string.bow_bonus_20), itemType = ShopBowItem.TYPE_BOW))
        shopItems.add(ShopBowItem("basic_bow", getString(R.string.bow_abyss_name), effectText = getString(R.string.bow_bonus_20), itemType = ShopBowItem.TYPE_BOW))
        
        // 가장 비싼 최고급 활 (공격속도 30% 보너스)
        shopItems.add(ShopBowItem("high_bow", getString(R.string.bow_astra_name), effectText = getString(R.string.bow_bonus_30), itemType = ShopBowItem.TYPE_BOW))

        // 3. 배틀 아이템 섹션
        shopItems.add(ShopBowItem("div_battle", getString(R.string.battle_item_section), itemType = ShopBowItem.TYPE_DIVIDER))
        shopItems.add(ShopBowItem("item_potion", getString(R.string.item_potion_name), effectText = getString(R.string.item_potion_desc), itemType = ShopBowItem.TYPE_BATTLE_ITEM, goldPrice = 500))
        shopItems.add(ShopBowItem("item_power", getString(R.string.item_power_name), effectText = getString(R.string.item_power_desc), itemType = ShopBowItem.TYPE_BATTLE_ITEM, goldPrice = 800))
        shopItems.add(ShopBowItem("item_slow", getString(R.string.item_slow_name), effectText = getString(R.string.item_slow_desc), itemType = ShopBowItem.TYPE_BATTLE_ITEM, goldPrice = 1200))
    }

    private fun handleItemAction(item: ShopBowItem) {
        if (item.itemType == ShopBowItem.TYPE_DIVIDER) return

        if (item.itemType == ShopBowItem.TYPE_BATTLE_ITEM) {
            val currentGold = purchaseStore.getGold()
            if (currentGold >= item.goldPrice) {
                if (purchaseStore.getItemCount(item.productId) < 10) {
                    purchaseStore.addGold(-item.goldPrice)
                    purchaseStore.addItem(item.productId, 1)
                    purchaseStore.incrementItemStat("stat_buy_${item.productId}")
                    updateUI()
                    Toast.makeText(this, getString(R.string.purchase_complete, item.displayName), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, getString(R.string.max_quantity_reached), Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, getString(R.string.not_enough_gold), Toast.LENGTH_SHORT).show()
            }
            return
        }

        if (item.isOwned) {
            purchaseStore.setEquippedBow(item.productId)
            updateUI()
            Toast.makeText(this, "${item.displayName} ${getString(R.string.equipped)}", Toast.LENGTH_SHORT).show()
        } else {
            billingManager.launchPurchaseFlow(item.productId)
        }
    }

    private fun updateUI() {
        val equippedId = purchaseStore.getEquippedBow()
        var ownedCount = 0

        shopItems.forEach { item ->
            if (item.itemType == ShopBowItem.TYPE_DIVIDER) return@forEach

            item.isOwned = purchaseStore.isOwned(item.productId)
            item.isEquipped = (item.productId == equippedId)
            
            if (item.isOwned && item.itemType == ShopBowItem.TYPE_BOW) {
                ownedCount++
            }
            
            if (item.itemType == ShopBowItem.TYPE_BATTLE_ITEM) {
                item.count = purchaseStore.getItemCount(item.productId)
                item.priceText = "${item.goldPrice}G"
            } else if (item.productId != "bow") {
                val price = billingManager.getPrice(item.productId)
                if (price != "가격 확인 중" && price != "Price checking...") {
                    item.priceText = price
                }
            }
        }

        inventoryStatusText.text = getString(R.string.inventory_status, ownedCount)
        goldText.text = getString(R.string.gold_status, purchaseStore.getGold())
        adapter.updateItems(shopItems)
    }

    override fun onResume() {
        super.onResume()
        billingManager.restorePurchases()
        updateUI()
    }
}
