package com.example.bowdefense

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AchievementActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievement)

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        val recyclerView = findViewById<RecyclerView>(R.id.achievementRecyclerView)
        val progressBar = findViewById<ProgressBar>(R.id.achievementProgressBar)
        val progressText = findViewById<TextView>(R.id.achievementProgressText)

        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = AchievementAdapter(emptyList())
        recyclerView.adapter = adapter

        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(this@AchievementActivity)
            db.gameDao().getAllAchievements().collectLatest { achievements ->
                runOnUiThread {
                    adapter.updateData(achievements)
                    val unlockedCount = achievements.count { it.isUnlocked }
                    progressBar.progress = unlockedCount
                    progressText.text = getString(R.string.achievement_progress, unlockedCount, achievements.size)
                }
            }
        }
    }
}
