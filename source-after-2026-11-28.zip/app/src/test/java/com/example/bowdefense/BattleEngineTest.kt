package com.example.bowdefense
import org.junit.Test
import org.junit.Assert.*
import java.io.*

class BattleEngineTest {
    private fun simulate(fps: Int): RunState {
        val e=BattleEngine(); e.aiming=true
        repeat(fps*20) { e.advance(1.0/fps) }
        return e.state
    }
    @Test fun frameRatesHaveIdenticalSimulation() {
        val a=simulate(30); val b=simulate(60); val c=simulate(120)
        assertEquals(a.time,b.time,1e-8); assertEquals(a.time,c.time,1e-8)
        assertEquals(a.shots,b.shots); assertEquals(a.score,b.score); assertEquals(a.hp,b.hp)
        assertEquals(a.enemies.map { it.x },b.enemies.map { it.x })
    }
    @Test fun idlePauseDoesNotAdvanceAnyTimers() {
        val s=RunState(power=20.0,slow=10.0,shockIn=15.0)
        val e=BattleEngine(s); repeat(60) { e.advance(1.0/60) }
        val before=s.time; e.advance(0.0)
        assertEquals(before,s.time,0.0); assertEquals(19.0,s.power,1e-8)
    }
    @Test fun firstChoiceFreezesClockAndRestoresExactly() {
        val e=BattleEngine(); e.state.hp=1000
        repeat(30*60) { e.advance(1.0/60) }
        assertEquals(25.0,e.state.time,.02); assertEquals(3,e.state.choices.size)
        val b=ByteArrayOutputStream(); ObjectOutputStream(b).use { it.writeObject(e.state) }
        val restored=ObjectInputStream(ByteArrayInputStream(b.toByteArray())).use { it.readObject() as RunState }
        assertEquals(e.state.sessionId,restored.sessionId); assertEquals(e.state.enemies,restored.enemies)
        assertEquals(e.state.choices,restored.choices)
        assertTrue(BattleEngine(restored).choose(restored.choices.first())); assertTrue(restored.firstChoiceAt>24)
    }
    @Test fun evolutionPrerequisitesAndCapsAreEnforced() {
        val e=BattleEngine(); assertFalse(2 in e.availableCards())
        e.state.levels[0]=2; e.state.levels[1]=1; assertTrue(2 in e.availableCards())
        e.state.levels[2]=1; assertFalse(2 in e.availableCards())
        e.state.levels[0]=3; assertFalse(0 in e.availableCards()); assertFalse(e.choose(0))
    }
    @Test fun damageRetainsFractionalPowerBonus() {
        val e=BattleEngine(); val base=e.damage(); e.state.power=1.0
        assertEquals(base*1.5,e.damage(),1e-9)
    }
    @Test fun continuationIsOnceAndKeepsBuildAndClock() {
        val s=RunState(time=83.0,hp=0,ended=true,gold=91); s.levels[0]=2
        val e=BattleEngine(s); assertTrue(e.revive()); assertEquals(83.0,s.time,0.0)
        assertEquals(2,s.levels[0]); assertEquals(91,s.gold); s.ended=true; assertFalse(e.revive())
    }
    @Test fun shockHasCooldownAndPierces() {
        val e=BattleEngine(); assertTrue(e.shock()); assertFalse(e.shock())
        assertTrue(e.state.bolts.single().shock); assertEquals(50,e.state.bolts.single().pierce)
    }
    @Test fun accuracyCountsAnArrowOnlyOnceWhenPiercing() {
        val s=RunState(spawnIn=99.0); s.enemies.add(Enemy(1,0,280.0,540.0,10.0,10.0)); s.enemies.add(Enemy(2,0,300.0,540.0,10.0,10.0))
        val e=BattleEngine(s); e.shock(); e.advance(1.0/60)
        assertEquals(1,s.hits); assertEquals(1,s.shots)
    }
    @Test fun scoreDoesNotIncreaseEnemyHealth() {
        val a=BattleEngine(RunState(score=0)); val b=BattleEngine(RunState(score=100000))
        repeat(61) { a.advance(1.0/60); b.advance(1.0/60) }
        assertEquals(a.state.enemies.first().maxHp,b.state.enemies.first().maxHp,0.0)
    }
    @Test fun chapterEndsAfterBossAndMinimumWaveTime() {
        val e=BattleEngine(RunState(wave=8,spawned=1,waveTime=29.0))
        repeat(61) { e.advance(1.0/60) }; assertTrue(e.state.cleared); assertTrue(e.state.ended)
    }
    @Test fun eachFreeArchetypeCanClearWithAimedPlay() {
        for(kind in 0..2) {
            val e=BattleEngine(RunState(archetype=kind))
            repeat(60*600) {
                val s=e.state
                if(s.choices.isNotEmpty()) {
                    val priority=when(kind) { 0->listOf(10,9,11,0,1,2,3,4,5,6,7,8); 1->listOf(0,1,2,10,9,11,3,4,5,6,7,8); else->listOf(3,4,5,10,9,11,0,1,2,6,7,8) }
                    e.choose(priority.first { it in s.choices })
                }
                val enemy=s.enemies.minByOrNull { it.x }
                if(enemy!=null) {
                    val lead=enemy.x-85*(enemy.x-250)/1500
                    e.aim=kotlin.math.atan2(enemy.y-540,lead-250); e.aiming=true
                    if(enemy.x<950 || enemy.kind==5 && enemy.age%12<2) e.shock()
                } else e.aiming=false
                if(!s.ended) e.advance(1.0/60)
            }
            println("BALANCE archetype=$kind clear=${e.state.cleared} time=${e.state.time.toInt()} wave=${e.state.wave} hp=${e.state.hp} kills=${e.state.kills}")
            assertTrue("Archetype $kind stopped at wave ${e.state.wave}",e.state.cleared)
            assertTrue("Chapter too long",e.state.time<360)
        }
    }
}
