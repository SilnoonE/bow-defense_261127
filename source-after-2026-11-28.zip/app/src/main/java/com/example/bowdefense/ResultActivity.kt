package com.example.bowdefense

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ResultActivity : BaseActivity() {

    private lateinit var lifeManager: LifeManager
    private lateinit var dataManager: DataManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        if (intent.getBooleanExtra("CLEARED", false)) {
            findViewById<TextView>(R.id.resultTitle).apply {
                setText(R.string.chapter_clear)
                setTextColor(android.graphics.Color.rgb(80, 220, 180))
            }
        }

        lifeManager = LifeManager(this)
        dataManager = DataManager(this)
        
        val score = intent.getIntExtra("SCORE", 0)
        val stage = intent.getIntExtra("STAGE", 1)
        val wave = intent.getIntExtra("WAVE", 1)
        val kills = intent.getIntExtra("KILLS", 0)
        val accuracy = intent.getFloatExtra("ACCURACY", 0f)
        val survivalTime = intent.getIntExtra("SURVIVAL_TIME", 0)
        val goldEarned = intent.getIntExtra("GOLD_EARNED", 0)
        val newAchievementIds = intent.getIntegerArrayListExtra("NEW_ACHIEVEMENTS") ?: arrayListOf()
        
        val cumulativeKills = intent.getIntExtra("CUMULATIVE_KILLS", 0)
        val currentDamage = intent.getIntExtra("CURRENT_DAMAGE", 1)
        val fireCooldown = intent.getLongExtra("FIRE_COOLDOWN", Config.BASE_FIRE_COOLDOWN)

        // 최고 점수 저장
        SaveManager(this).saveHighScore(score)

        findViewById<TextView>(R.id.finalScoreText).text = getString(R.string.current_score, score)
        findViewById<TextView>(R.id.survivalTimeText).text = getString(R.string.survival_time, survivalTime)
        findViewById<TextView>(R.id.totalKillsText).text = getString(R.string.total_kills, kills)
        findViewById<TextView>(R.id.accuracyText).text = getString(R.string.accuracy, accuracy.toInt())
        findViewById<TextView>(R.id.goldEarnedText).text = getString(R.string.gold_earned, goldEarned)
        findViewById<TextView>(R.id.finalStageText).text = "${getString(R.string.final_stage, stage)} - Wave $wave"
        findViewById<TextView>(R.id.bestScoreText).text = getString(R.string.best_score_result, SaveManager(this).getHighScore())

        // AI 분석 한줄
        val aiAnalysisShort = findViewById<TextView>(R.id.aiAnalysisShort)
        val levels=intent.getIntArrayExtra("BUILD") ?: IntArray(12)
        val names=resources.getStringArray(R.array.card_names)
        val build=levels.indices.filter { levels[it]>0 }.joinToString(" · ") { "${names[it]} ${levels[it]}" }
        val cause=intent.getIntExtra("DEATH_KIND",-1)
        val enemies=resources.getStringArray(R.array.enemy_names)
        aiAnalysisShort.text=getString(R.string.battle_feedback)+"\n"+
            (if(intent.getBooleanExtra("CLEARED",false)) getString(R.string.chapter_clear) else if(cause in enemies.indices) getString(R.string.defeated_by,enemies[cause]) else "")+
            "\n"+build+"\n"+getString(R.string.best_difference,score-intent.getIntExtra("PREVIOUS_BEST",0))+"\n"+
            (if(accuracy<40) getString(R.string.ai_analysis_4) else if(intent.getIntExtra("SHOCK_USES",0)==0) getString(R.string.try_shock) else getString(R.string.ai_analysis_default))

        val progress=PurchaseStore(this)
        aiAnalysisShort.append("\n"+getString(R.string.next_goals,progress.getHighScore().coerceAtMost(500),if(progress.chapterCleared()) 1 else 0,progress.supplyPurchases().coerceAtMost(1)))

        // 새 업적 표시
        if (newAchievementIds.isNotEmpty()) {
            val titleView = findViewById<TextView>(R.id.newAchievementsTitle)
            val listView = findViewById<TextView>(R.id.newAchievementsList)
            titleView.visibility = View.VISIBLE
            listView.visibility = View.VISIBLE
            
            lifecycleScope.launch {
                val db = AppDatabase.getDatabase(this@ResultActivity)
                val allAchievements = db.gameDao().getAllAchievements().first()
                val newAchievements = allAchievements.filter { it.id in newAchievementIds }
                val text = newAchievements.joinToString("\n") { 
                    val nameResId = resources.getIdentifier("achievement_name_${it.id}", "string", packageName)
                    val localizedName = if (nameResId != 0) getString(nameResId) else it.name
                    "★ $localizedName (+${it.rewardGold}G)" 
                }
                runOnUiThread { listView.text = text }
            }
        }

        val continueButton = findViewById<Button>(R.id.continueButton)
        val restartButton = findViewById<Button>(R.id.restartButton)
        val mainButton = findViewById<Button>(R.id.mainButton)
        val viewRecordButton = findViewById<Button>(R.id.viewRecordButton)

        val lives = lifeManager.getLifeCount()
        if (RunRepository(this).load()?.let { it.ended && !it.cleared && !it.continued && PurchaseStore(this).canContinue(it.sessionId) } == true) {
            continueButton.visibility = View.VISIBLE
            continueButton.text = getString(R.string.continue_with_lives, lives)
        } else {
            continueButton.visibility = View.GONE
        }

        continueButton.setOnClickListener {
            continueButton.isEnabled=false
            if (RunRepository(this).load()?.let { PurchaseStore(this).reserveContinue(it.sessionId) } == true) {
                GameSessionManager.hasContinuedThisGame = true
                val intent = Intent(this, GameActivity::class.java).apply {
                    putExtra("CONTINUE_GAME", true)
                    putExtra("LAST_SCORE", score)
                    putExtra("LAST_STAGE", stage)
                    putExtra("LAST_WAVE", wave)
                    putExtra("CUMULATIVE_KILLS", cumulativeKills)
                    putExtra("CURRENT_DAMAGE", currentDamage)
                    putExtra("FIRE_COOLDOWN", fireCooldown)
                }
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, getString(R.string.not_enough_lives), Toast.LENGTH_SHORT).show()
                continueButton.visibility = View.GONE
            }
        }

        restartButton.setOnClickListener {
            PurchaseStore(this).incrementItemStat("v2_retries")
            RunRepository(this).clear()
            GameSessionManager.reset()
            startActivity(Intent(this, GameActivity::class.java))
            finish()
        }

        mainButton.setOnClickListener {
            finish()
        }

        viewRecordButton.setOnClickListener {
            startActivity(Intent(this, RecordActivity::class.java))
        }
    }

    private fun generateAiAnalysis(score: Int, accuracy: Float, survivalTime: Int): String {
        val store = PurchaseStore(this)
        val potionUse = store.getItemStat("stat_use_item_potion")
        val powerUse = store.getItemStat("stat_use_item_power")
        val slowUse = store.getItemStat("stat_use_item_slow")

        return when {
            potionUse > 10 && survivalTime < 120 -> getString(R.string.ai_analysis_1)
            powerUse > 5 && accuracy > 70 -> getString(R.string.ai_analysis_2)
            slowUse > 5 && survivalTime > 300 -> getString(R.string.ai_analysis_3)
            accuracy < 40 -> getString(R.string.ai_analysis_4)
            survivalTime < 60 -> getString(R.string.ai_analysis_5)
            score > 5000 -> getString(R.string.ai_analysis_6)
            else -> getString(R.string.ai_analysis_default)
        }
    }
}
