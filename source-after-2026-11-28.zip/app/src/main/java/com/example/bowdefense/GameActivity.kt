package com.example.bowdefense
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class GameActivity: BaseActivity() {
    private lateinit var game: GameView
    private lateinit var sound: SoundManager
    private lateinit var store: PurchaseStore
    private lateinit var repository: RunRepository
    private lateinit var shock: Button
    private var paused=false
    private var finished=false
    private var choiceDialog: AlertDialog?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_game)
        onBackPressedDispatcher.addCallback(this,object: androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if(paused) resumeBattle() else pauseBattle() }
        })
        store=PurchaseStore(this); repository=RunRepository(this); sound=SoundManager(this)
        game=findViewById(R.id.gameView); game.setSoundManager(sound)
        val restored=if(savedInstanceState!=null || intent.getBooleanExtra("RESUME_RUN",false) || intent.getBooleanExtra("CONTINUE_GAME",false)) repository.load() else null
        val state=restored ?: RunState(archetype=intent.getIntExtra("ARCHETYPE",0),endless=intent.getBooleanExtra("ENDLESS",false),previousBest=store.getHighScore(),bowMultiplier=when(store.getEquippedBow()) { "bow"->1.0; "high_bow"->.7; else->.8 })
        if(intent.getBooleanExtra("CONTINUE_GAME",false) && state.ended && store.reserveContinue(state.sessionId)) { BattleEngine(state).revive(); repository.save(state) }
        if(restored==null) {
            state.goldSpent=store.preparationSpent(); state.purchases=store.preparationPurchases()
            repository.save(state); store.markPreparationUsed(); store.incrementItemStat("v2_runs")
        }
        game.configure(state)
        findViewById<Button>(R.id.pauseButton).setOnClickListener { pauseBattle() }
        findViewById<Button>(R.id.resumeButton).setOnClickListener { resumeBattle() }
        findViewById<Button>(R.id.settingsButtonInGame).setOnClickListener { settings() }
        findViewById<Button>(R.id.exitButton).setOnClickListener { game.checkpoint(); finish() }
        findViewById<LinearLayout>(R.id.pauseScreen).addView(Button(this).apply {
            layoutParams=LinearLayout.LayoutParams((180*resources.displayMetrics.density).toInt(),LinearLayout.LayoutParams.WRAP_CONTENT)
            backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF176B70.toInt())
            setTextColor(android.graphics.Color.WHITE)
            text=getString(R.string.choose_upgrade)
            setOnClickListener {
                val names=resources.getStringArray(R.array.card_names)
                val descriptions=resources.getStringArray(R.array.card_descriptions)
                val levels=game.snapshot().levels
                AlertDialog.Builder(this@GameActivity,R.style.BattleDialog).setTitle(R.string.choose_upgrade)
                    .setItems(names.indices.map { "${names[it]} ${levels[it]}/${if(it%3==2) 1 else 3}\n${descriptions[it]}" }.toTypedArray()) { _,_ -> }.show()
            }
        })
        findViewById<View>(R.id.slotPotion).setOnClickListener { game.useItem("item_potion") }
        findViewById<View>(R.id.slotPower).setOnClickListener { game.useItem("item_power") }
        findViewById<View>(R.id.slotSlow).setOnClickListener { game.useItem("item_slow") }
        shock=Button(this).apply {
            text=getString(R.string.shock_ready)
            backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF176B70.toInt())
            setTextColor(android.graphics.Color.WHITE)
            setOnClickListener { game.command { it.shock() } }
        }
        findViewById<LinearLayout>(R.id.itemSlotsLayout).addView(shock,0)
        game.onHud={ updateHud(it) }
        game.onChoice={ cards ->
            if(!isFinishing && choiceDialog?.isShowing!=true) {
                val s=game.snapshot()
                val names=resources.getStringArray(R.array.card_names); val desc=resources.getStringArray(R.array.card_descriptions)
                choiceDialog=AlertDialog.Builder(this,R.style.BattleDialog).setTitle(R.string.choose_upgrade)
                    .setItems(cards.map { "${names[it]}  ${s.levels[it]}/${if(it%3==2) 1 else 3}\n${desc[it]}" }.toTypedArray()) { _,i -> game.choose(cards[i]) }
                    .setCancelable(false).show()
            }
        }
        game.onFinished={ finishRun(it) }
        updateHud(state)
        paused=savedInstanceState?.getBoolean("paused",false) ?: false
        if(paused) findViewById<View>(R.id.pauseScreen).visibility=View.VISIBLE
    }
    private fun updateHud(s: RunState) {
        findViewById<TextView>(R.id.stageTextView).text=getString(R.string.battle_wave,s.wave,if(s.endless) "∞" else "8",s.time.toInt())
        findViewById<TextView>(R.id.scoreTextView).text=getString(R.string.score_label,s.score)
        findViewById<ProgressBar>(R.id.hpProgressBar).apply { max=10; progress=s.hp }
        listOf(Triple(R.id.slotPotion,R.id.countPotion,"item_potion"),Triple(R.id.slotPower,R.id.countPower,"item_power"),Triple(R.id.slotSlow,R.id.countSlow,"item_slow")).forEach { (slot,count,id) ->
            val n=store.getItemCount(id); findViewById<View>(slot).visibility=if(n>0) View.VISIBLE else View.GONE
            findViewById<TextView>(count).text="×$n"
        }
        findViewById<TextView>(R.id.powerArrowTimer).apply { visibility=if(s.power>0) View.VISIBLE else View.GONE; text=getString(R.string.power_arrow_timer,kotlin.math.ceil(s.power).toInt()) }
        findViewById<TextView>(R.id.slowStoneTimer).apply { visibility=if(s.slow>0) View.VISIBLE else View.GONE; text=getString(R.string.slow_stone_timer,kotlin.math.ceil(s.slow).toInt()) }
        shock.text=if(s.shockIn<=0) getString(R.string.shock_ready) else getString(R.string.shock_wait,kotlin.math.ceil(s.shockIn).toInt())
        shock.isEnabled=s.shockIn<=0 && !s.ended && s.choices.isEmpty()
    }
    private fun finishRun(s: RunState) {
        if(finished) return; finished=true
        game.pause(); sound.pauseBGM()
        lifecycleScope.launch {
            val record=GameRecord(playDate=s.createdAt,survivalTimeSeconds=s.time.toInt(),score=s.score,killCount=s.kills,arrowsShot=s.shots,hitCount=s.hits,
                accuracy=if(s.shots>0) s.hits*100f/s.shots else 0f,goldEarned=s.gold,goldSpent=s.goldSpent,shopPurchaseCount=s.purchases,bowChangeCount=0,
                maxStage=(s.wave-1)/3+1,maxWave=(s.wave-1)%3+1,resultType=if(s.cleared) "CLEAR" else "DEAD",isLowHpSurvivalAchieved=s.lowHpAchieved,sessionId=s.sessionId)
            val achievements=RunFinalizer.finish(this@GameActivity,s)
            store.commitRunGold(s.sessionId,s.gold); store.saveHighScore(s.score)
            if(s.cleared) store.setChapterCleared()
            startActivity(Intent(this@GameActivity,ResultActivity::class.java).apply {
                putExtra("SCORE",s.score); putExtra("STAGE",record.maxStage); putExtra("WAVE",record.maxWave); putExtra("KILLS",s.kills)
                putExtra("ACCURACY",record.accuracy); putExtra("SURVIVAL_TIME",record.survivalTimeSeconds); putExtra("GOLD_EARNED",s.gold)
                putExtra("RUN_V2",true); putExtra("CLEARED",s.cleared); putExtra("PREVIOUS_BEST",s.previousBest)
                putExtra("BUILD",s.levels); putExtra("DEATH_KIND",s.deathKind); putExtra("SHOCK_USES",s.shockUses)
                putIntegerArrayListExtra("NEW_ACHIEVEMENTS",ArrayList(achievements.map { it.id }))
            }); finish()
        }
    }
    private fun settings() {
        val options=arrayOf(getString(R.string.change_language),getString(R.string.bgm_setting),getString(R.string.vibration_setting),getString(R.string.screen_shake))
        AlertDialog.Builder(this,R.style.BattleDialog).setTitle(R.string.settings).setItems(options) { _,i -> when(i) {
            0->AlertDialog.Builder(this,R.style.BattleDialog).setTitle(R.string.select_language).setItems(arrayOf("English","한국어","Español","中文","日本語")) { _,j ->
                game.checkpoint(); LocaleHelper.setLocale(this,arrayOf("en","ko","es","zh","ja")[j]); intent.putExtra("RESUME_RUN",true); recreate()
            }.show()
            1->store.setBgmEnabled(!store.isBgmEnabled())
            2->store.setVibrationEnabled(!store.isVibrationEnabled())
            3->store.setShakeEnabled(!store.isShakeEnabled())
        } }.show()
    }
    private fun pauseBattle() { paused=true; game.pause(); sound.pauseBGM(); findViewById<View>(R.id.pauseScreen).visibility=View.VISIBLE }
    private fun resumeBattle() { paused=false; findViewById<View>(R.id.pauseScreen).visibility=View.GONE; game.resume(); sound.startBGM() }
    override fun onSaveInstanceState(outState: Bundle) { game.checkpoint(); outState.putBoolean("paused",paused); super.onSaveInstanceState(outState) }
    override fun onPause() { game.pause(); sound.pauseBGM(); super.onPause() }
    override fun onResume() { super.onResume(); if(!paused && !finished) { game.resume(); sound.startBGM() } }
    override fun onDestroy() { game.pause(); choiceDialog?.dismiss(); sound.release(); super.onDestroy() }
}

