package com.example.bowdefense

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {

    private lateinit var saveManager: SaveManager
    private lateinit var lifeManager: LifeManager
    private lateinit var dataManager: DataManager
    private lateinit var highScoreText: TextView
    private lateinit var lifeCountText: TextView
    private lateinit var adView: AdView
    private lateinit var purchaseStore: PurchaseStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Mobile Ads SDK 초기화
        if (BuildConfig.ADS_ENABLED) MobileAds.initialize(this) {}

        saveManager = SaveManager(this)
        lifeManager = LifeManager(this)
        dataManager = DataManager(this)
        purchaseStore = PurchaseStore(this)

        // 업적 초기화
        lifecycleScope.launch {
            dataManager.initAchievements()
            RunRepository(this@MainActivity).load()?.takeIf { it.ended }?.let { RunFinalizer.finish(this@MainActivity,it) }
            dataManager.refreshShopAchievements()
            updateUI()
        }

        highScoreText = findViewById(R.id.highScoreTextView)
        lifeCountText = findViewById(R.id.lifeCountTextView)
        val startButton = findViewById<Button>(R.id.startButton)
        val shopButton = findViewById<Button>(R.id.shopButton)
        val recordButton = findViewById<Button>(R.id.recordButton)
        val achievementButton = findViewById<Button>(R.id.achievementButton)
        val settingsButton = findViewById<ImageButton>(R.id.settingsButton)

        updateUI()

        // 광고 로드
        adView = findViewById(R.id.adViewMain)
        val adRequest = AdRequest.Builder().build()
        if (BuildConfig.ADS_ENABLED) adView.loadAd(adRequest) else adView.visibility=android.view.View.GONE

        // 게임 시작
        startButton.setOnClickListener {
            val saved=RunRepository(this).load()
            if(saved!=null && !saved.ended) {
                AlertDialog.Builder(this).setTitle(R.string.resume).setMessage(R.string.resume_checkpoint)
                    .setPositiveButton(R.string.resume) { _,_ -> startActivity(Intent(this,GameActivity::class.java).putExtra("RESUME_RUN",true)) }
                    .setNegativeButton(R.string.new_expedition) { _,_ -> chooseMode() }.show()
            } else chooseMode()
        }

        // 상점 이동
        shopButton.setOnClickListener {
            lifecycleScope.launch {
                dataManager.incrementShopVisit()
            }
            val intent = Intent(this, ShopActivity::class.java)
            startActivity(intent)
        }

        recordButton.setOnClickListener {
            startActivity(Intent(this, RecordActivity::class.java))
        }

        achievementButton.setOnClickListener {
            startActivity(Intent(this, AchievementActivity::class.java))
        }

        settingsButton.setOnClickListener {
            showSettingsDialog()
        }
    }

    private fun chooseMode() {
        val modes=resources.getStringArray(R.array.archetypes)
        val unlocked=if(purchaseStore.chapterCleared()) 3 else if(purchaseStore.getHighScore()>=500) 2 else 1
        AlertDialog.Builder(this).setTitle(R.string.choose_weapon).setItems(modes.take(unlocked).toTypedArray()) { _,kind ->
            val begin: (Boolean)->Unit = { endless ->
                lifecycleScope.launch {
                    val repository=RunRepository(this@MainActivity)
                    repository.load()?.takeIf { !it.ended }?.let { old ->
                        old.ended=true; old.abandoned=true; repository.save(old)
                        RunFinalizer.finish(this@MainActivity,old)
                    }
                    repository.clear(); GameSessionManager.reset()
                    startActivity(Intent(this@MainActivity,GameActivity::class.java).putExtra("ARCHETYPE",kind).putExtra("ENDLESS",endless))
                }
            }
            if(purchaseStore.chapterCleared()) AlertDialog.Builder(this).setTitle(R.string.choose_mode)
                .setItems(resources.getStringArray(R.array.battle_modes)) { _,mode -> begin(mode==1) }.show()
            else begin(false)
        }.show()
    }

    private fun showSettingsDialog() {
        val bgmStatus = if (purchaseStore.isBgmEnabled()) getString(R.string.on) else getString(R.string.off)
        val vibStatus = if (purchaseStore.isVibrationEnabled()) getString(R.string.on) else getString(R.string.off)

        val options = arrayOf(
            getString(R.string.change_language),
            "${getString(R.string.bgm_setting)}: $bgmStatus",
            "${getString(R.string.vibration_setting)}: $vibStatus"
        )

        AlertDialog.Builder(this)
            .setTitle(R.string.settings)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showLanguageDialog()
                    1 -> {
                        purchaseStore.setBgmEnabled(!purchaseStore.isBgmEnabled())
                        showSettingsDialog()
                    }
                    2 -> {
                        purchaseStore.setVibrationEnabled(!purchaseStore.isVibrationEnabled())
                        showSettingsDialog()
                    }
                }
            }
            .show()
    }

    private fun showLanguageDialog() {
        val languages = arrayOf("English (영어)", "한국어 (Korean)", "Español", "中文", "日本語")
        val langCodes = arrayOf("en", "ko", "es", "zh", "ja")

        AlertDialog.Builder(this)
            .setTitle(R.string.select_language)
            .setItems(languages) { _, which ->
                val selectedLang = langCodes[which]
                LocaleHelper.setLocale(this, selectedLang)
                recreate()
            }
            .show()
    }

    private fun updateUI() {
        highScoreText.text = getString(R.string.high_score, saveManager.getHighScore())
        lifeCountText.text = getString(R.string.life_count, lifeManager.getLifeCount()) + "\n" +
            getString(R.string.next_goals, purchaseStore.getHighScore().coerceAtMost(500), if(purchaseStore.chapterCleared()) 1 else 0, purchaseStore.supplyPurchases().coerceAtMost(1))
    }

    override fun onResume() {
        super.onResume()
        updateUI()
        adView.resume()
    }

    override fun onPause() {
        adView.pause()
        super.onPause()
    }

    override fun onDestroy() {
        adView.destroy()
        super.onDestroy()
    }
}

