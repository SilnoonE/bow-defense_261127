package com.example.bowdefense
import android.content.Context
import android.util.AtomicFile
import java.io.*
class RunRepository(context: Context) {
    private val file = AtomicFile(File(context.filesDir,"run-v2.bin"))
    fun save(state: RunState) = synchronized(lock) {
        val out=file.startWrite()
        try {
            val bytes=ByteArrayOutputStream().also { b -> ObjectOutputStream(b).use { it.writeInt(2); it.writeObject(state) } }.toByteArray()
            out.write(bytes); file.finishWrite(out)
        } catch(e: Exception) { file.failWrite(out); throw e }
    }
    fun load(): RunState? = synchronized(lock) {
        try { ObjectInputStream(file.openRead()).use { if(it.readInt()==2) it.readObject() as RunState else null } } catch(_: Exception) { null }
    }
    fun clear() = synchronized(lock) { file.delete() }
    companion object { private val lock=Any() }
}
