package com.example.bowdefense

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.util.Log

/**
 * 게임 효과음 및 배경음악을 관리하는 매니저 클래스입니다.
 */
class SoundManager(val context: Context) {
    private var soundPool: SoundPool
    private var shootSoundId: Int = 0
    private var hitSoundId: Int = 0
    private var killSoundId: Int = 0
    private var bgmPlayer: MediaPlayer? = null
    private val purchaseStore = PurchaseStore(context)

    init {
        // 효과음 설정 (SoundPool)
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(audioAttributes)
            .build()

        try {
            // res/raw/shootingarrow.mp3 로드
            shootSoundId = soundPool.load(context, R.raw.shootingarrow, 1)
            hitSoundId = soundPool.load(context,R.raw.impact,1)
            killSoundId = soundPool.load(context,R.raw.defeat,1)
        } catch (e: Exception) {
            Log.e("SoundManager", "Error loading sound effect", e)
        }

        // 배경음악 설정 (MediaPlayer)
        try {
            bgmPlayer = MediaPlayer.create(context, R.raw.throneofashes)
            bgmPlayer?.isLooping = true // 무한 반복
            bgmPlayer?.setVolume(0.5f, 0.5f) // 배경음악 볼륨 조절
        } catch (e: Exception) {
            Log.e("SoundManager", "Error loading BGM: thronsofashes", e)
        }
    }

    fun playShoot() {
        if (shootSoundId != 0) {
            soundPool.play(shootSoundId, 1f, 1f, 1, 0, 1f)
        }
    }

    fun playHit() { soundPool.play(hitSoundId,.35f,.35f,1,0,1f) }
    fun playKill() { soundPool.play(killSoundId,.4f,.4f,1,0,1f) }
    fun startBGM() {
        if (!purchaseStore.isBgmEnabled()) return
        try {
            if (bgmPlayer?.isPlaying == false) {
                bgmPlayer?.start()
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Error starting BGM", e)
        }
    }

    fun pauseBGM() {
        try {
            if (bgmPlayer?.isPlaying == true) {
                bgmPlayer?.pause()
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Error pausing BGM", e)
        }
    }

    fun stopBGM() {
        try {
            bgmPlayer?.stop()
            bgmPlayer?.prepare() // 나중에 다시 재생할 수 있도록 준비
        } catch (e: Exception) {
            Log.e("SoundManager", "Error stopping BGM", e)
        }
    }

    fun release() {
        soundPool.release()
        bgmPlayer?.stop()
        bgmPlayer?.release()
        bgmPlayer = null
    }
}
