package com.example.bowdefense

import android.content.Context
import android.content.SharedPreferences

/**
 * 모든 영구 데이터(구매 내역, 장착 상태, 점수, 생명)를 관리하는 통합 클래스입니다.
 */
class PurchaseStore(context: Context, preferenceName: String = "BowDefensePrefs") {
    private val prefs: SharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE)

    // 최고 점수 관리
    fun saveHighScore(score: Int) = synchronized(transactionLock) {
        val currentHigh = getHighScore()
        if (score > currentHigh) {
            prefs.edit().putInt("high_score", score).apply()
        }
    }
    fun getHighScore(): Int = prefs.getInt("high_score", 0)

    // 골드 관리
    fun getGold(): Int = prefs.getInt("total_gold", 0)
    fun addGold(amount: Int) = synchronized(transactionLock) {
        prefs.edit().putInt("total_gold", getGold() + amount).apply()
    }

    // 아이템 수량 관리
    fun getItemCount(itemId: String): Int = prefs.getInt("item_$itemId", 0)
    fun addItem(itemId: String, count: Int) = synchronized(transactionLock) {
        val current = getItemCount(itemId)
        prefs.edit().putInt("item_$itemId", (current + count).coerceIn(0, 10)).apply()
    }
    fun useItem(itemId: String): Boolean = synchronized(transactionLock) {
        val current = getItemCount(itemId)
        if (current > 0) {
            prefs.edit().putInt("item_$itemId", current - 1).apply()
            return@synchronized true
        }
        false
    }

    // 아이템 통계
    fun incrementItemStat(statKey: String) = synchronized(transactionLock) {
        val current = prefs.getInt(statKey, 0)
        prefs.edit().putInt(statKey, current + 1).apply()
    }
    fun getItemStat(statKey: String): Int = prefs.getInt(statKey, 0)

    // 생명(이어하기 아이템) 관리
    fun getLifeCount(): Int = prefs.getInt("life_count", 0)
    fun addLives(count: Int) = synchronized(transactionLock) {
        prefs.edit().putInt("life_count", getLifeCount() + count).apply()
    }

    // 스킨 소유 여부 관리
    fun isOwned(productId: String): Boolean {
        if (productId == "bow") return true // 기본 활은 항상 소유
        return prefs.getBoolean("owned_$productId", false)
    }
    fun setOwned(productId: String, owned: Boolean) = synchronized(transactionLock) {
        prefs.edit().putBoolean("owned_$productId", owned).apply()
    }

    // 현재 장착된 활 ID 가져오기 (기본값: bow)
    fun getEquippedBow(): String {
        return prefs.getString("equipped_bow", "bow") ?: "bow"
    }

    // 활 장착 상태 저장
    fun setEquippedBow(productId: String) = synchronized(transactionLock) {
        prefs.edit().putString("equipped_bow", productId).apply()
    }

    // 설정 관리
    fun isBgmEnabled(): Boolean = prefs.getBoolean("bgm_enabled", true)
    fun setBgmEnabled(enabled: Boolean) = synchronized(transactionLock) {
        prefs.edit().putBoolean("bgm_enabled", enabled).apply()
    }
    fun isVibrationEnabled(): Boolean = prefs.getBoolean("vibration_enabled", true)
    fun setVibrationEnabled(enabled: Boolean) = synchronized(transactionLock) {
        prefs.edit().putBoolean("vibration_enabled", enabled).apply()
    }

    companion object { private val transactionLock = Any() }
    fun isShakeEnabled() = prefs.getBoolean("screen_shake", true)
    fun setShakeEnabled(enabled: Boolean) { prefs.edit().putBoolean("screen_shake",enabled).apply() }
    fun chapterCleared() = prefs.getBoolean("chapter_clear_v2",false)
    fun setChapterCleared() { prefs.edit().putBoolean("chapter_clear_v2",true).commit() }
    fun awardOnce(key: String, amount: Int) = synchronized(transactionLock) {
        if (!prefs.getBoolean("awarded_$key",false)) prefs.edit().putInt("total_gold",getGold()+amount.coerceAtLeast(0)).putBoolean("awarded_$key",true).commit()
    }
    fun commitRunGold(session: String, gold: Int) = synchronized(transactionLock) {
        val paid=prefs.getInt("run_paid_$session",0)
        if(gold>paid) prefs.edit().putInt("total_gold",getGold()+gold-paid).putInt("run_paid_$session",gold).commit()
    }
    fun buySupply(id: String, price: Int): Boolean = synchronized(transactionLock) {
        if(getGold()<price || getItemCount(id)>=10) return@synchronized false
        prefs.edit().putInt("total_gold",getGold()-price).putInt("item_$id",getItemCount(id)+1)
            .putInt("supply_purchases",prefs.getInt("supply_purchases",0)+1)
            .putInt("supply_spent",prefs.getInt("supply_spent",0)+price).commit()
    }
    fun supplyPurchases() = prefs.getInt("supply_purchases",0)
    fun supplySpent() = prefs.getInt("supply_spent",0)
    fun preparationSpent() = supplySpent()-prefs.getInt("prepared_spent",0)
    fun preparationPurchases() = supplyPurchases()-prefs.getInt("prepared_purchases",0)
    fun markPreparationUsed() { prefs.edit().putInt("prepared_spent",supplySpent()).putInt("prepared_purchases",supplyPurchases()).commit() }
    fun metricOnce(event: String, key: String) = synchronized(transactionLock) {
        if(!prefs.getBoolean("metric_$event",false)) prefs.edit().putBoolean("metric_$event",true).putInt(key,getItemStat(key)+1).commit()
    }

    fun canContinue(session: String): Boolean = getLifeCount()>0 || prefs.getBoolean("continue_$session",false)
    fun reserveContinue(session: String): Boolean = synchronized(transactionLock) {
        if(prefs.getBoolean("continue_$session",false)) return@synchronized true
        if(getLifeCount()<=0) return@synchronized false
        prefs.edit().putInt("life_count",getLifeCount()-1).putBoolean("continue_$session",true).commit()
    }
}
