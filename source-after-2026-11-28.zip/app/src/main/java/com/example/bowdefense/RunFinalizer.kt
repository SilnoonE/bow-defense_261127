package com.example.bowdefense
import android.content.Context

/** Replayed at startup after a crash; Room session updates and wallet credit are idempotent. */
object RunFinalizer {
    fun record(s: RunState) = GameRecord(playDate=s.createdAt,survivalTimeSeconds=s.time.toInt(),score=s.score,killCount=s.kills,
        arrowsShot=s.shots,hitCount=s.hits,accuracy=if(s.shots>0) s.hits*100f/s.shots else 0f,
        goldEarned=s.gold,goldSpent=s.goldSpent,shopPurchaseCount=s.purchases,bowChangeCount=0,
        maxStage=(s.wave-1)/3+1,maxWave=(s.wave-1)%3+1,resultType=if(s.cleared) "CLEAR" else if(s.abandoned) "EXIT" else "DEAD",
        isLowHpSurvivalAchieved=s.lowHpAchieved,sessionId=s.sessionId)
    suspend fun finish(context: Context,s: RunState): List<Achievement> {
        val manager=DataManager(context)
        manager.initAchievements()
        val achievements=manager.saveGameRecord(record(s))
        PurchaseStore(context).apply {
            commitRunGold(s.sessionId,s.gold); saveHighScore(s.score)
            if(s.cleared) setChapterCleared()
            metricOnce("finish_${s.sessionId}","v2_finished")
            if(s.time<30 && !s.abandoned) metricOnce("early_${s.sessionId}","v2_death_before_30s")
            if(s.wave>=8) metricOnce("boss_${s.sessionId}","v2_boss_reached")
            if(s.cleared) metricOnce("clear_${s.sessionId}","v2_clear_archetype_${s.archetype}")
        }
        return achievements
    }
}
