package com.example.bowdefense
import android.content.Context
import android.graphics.*
import android.os.*
import android.util.AttributeSet
import android.view.*
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

class GameView(context: Context, attrs: AttributeSet?=null): SurfaceView(context,attrs), SurfaceHolder.Callback,Runnable {
    private var engine=BattleEngine()
    private val commands=ConcurrentLinkedQueue<(BattleEngine)->Unit>()
    private val lock=Any()
    private var thread: Thread?=null
    @Volatile private var running=false
    private var ready=false
    private var wanted=false
    private var sound: SoundManager?=null
    private val store=PurchaseStore(context)
    private val repository=RunRepository(context)
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private val background=BitmapFactory.decodeResource(resources,R.drawable.background)
    private val sprites=listOf(R.drawable.normal,R.drawable.fast,R.drawable.tank,R.drawable.enemy_shield,R.drawable.enemy_summoner,R.drawable.enemy_boss).map { BitmapFactory.decodeResource(resources,it) }
    private val bow=BitmapFactory.decodeResource(resources,resources.getIdentifier(store.getEquippedBow(),"drawable",context.packageName).takeIf { it!=0 } ?: R.drawable.bow)
    private var shake=0.0
    private var reportedEnd=false
    private var lastHud=0L
    private var lastSave=0.0
    private var choiceShown=false
    var onHud: ((RunState)->Unit)?=null
    var onChoice: ((List<Int>)->Unit)?=null
    var onFinished: ((RunState)->Unit)?=null
    init { holder.addCallback(this) }
    fun configure(state: RunState) { synchronized(lock) { engine=BattleEngine(state) } }
    fun setSoundManager(manager: SoundManager) { sound=manager }
    fun command(action: (BattleEngine)->Unit) { commands.add(action) }
    private fun drain() { while(true) { val c=commands.poll() ?: break; c(engine) } }
    fun checkpoint() = synchronized(lock) { drain(); repository.save(engine.state) }
    fun snapshot(): RunState = synchronized(lock) {
        val b=java.io.ByteArrayOutputStream()
        java.io.ObjectOutputStream(b).use { it.writeObject(engine.state) }
        java.io.ObjectInputStream(java.io.ByteArrayInputStream(b.toByteArray())).use { it.readObject() as RunState }
    }
    fun choose(id: Int) { command {
        val first=it.state.firstChoiceAt<0
        if(it.choose(id)) {
            store.incrementItemStat("v2_card_$id")
            if(first) store.incrementItemStat("v2_first_choice_reached")
        }
        choiceShown=false; repository.save(it.state)
    } }
    fun useItem(id: String) { command { e ->
        val s=e.state
        if(s.ended || s.choices.isNotEmpty()) return@command
        val usable=when(id) { "item_potion"->s.hp<10; "item_power"->s.power<=0; else->s.slow<=0 }
        if(usable && store.useItem(id)) {
            when(id) {
                "item_potion"->{ if(s.hp==1) store.incrementItemStat("stat_use_item_potion_at_hp1"); s.hp=min(10,s.hp+3); s.potionUses++ }
                "item_power"->{ s.power=20.0; s.powerUses++ }
                else->{ s.slow=10.0; s.slowUses++ }
            }
            store.incrementItemStat("stat_use_$id"); repository.save(s)
        }
    } }
    override fun surfaceCreated(holder: SurfaceHolder) { ready=true; synchronized(lock) { render() }; if(wanted) start() }
    override fun surfaceChanged(holder: SurfaceHolder,format: Int,width: Int,height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) { ready=false; stop() }
    fun resume() { wanted=true; start() }
    fun pause() { wanted=false; stop(); checkpoint() }
    @Synchronized private fun start() { if(!ready || running) return; running=true; thread=Thread(this,"BattleLoop").also { it.start() } }
    private fun stop() { running=false; thread?.join(); thread=null; synchronized(lock) { engine.aiming=false } }
    override fun run() {
        var previous=System.nanoTime()
        while(running) {
            val now=System.nanoTime(); val dt=(now-previous)/1e9; previous=now
            synchronized(lock) {
                drain(); engine.advance(dt)
                val s=engine.state
                if(engine.shotEvent) { sound?.playShoot(); engine.shotEvent=false }
                if(engine.hitEvent) { sound?.playHit(); engine.hitEvent=false }
                if(engine.killEvent) { sound?.playKill(); engine.killEvent=false }
                if(engine.hurtEvent) {
                    shake=.25; engine.hurtEvent=false
                    if(store.isVibrationEnabled()) {
                        val v=context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        if(Build.VERSION.SDK_INT>=26) v.vibrate(VibrationEffect.createOneShot(35,80)) else v.vibrate(35)
                    }
                }
                shake=max(0.0,shake-dt)
                if(now-lastHud>100_000_000) { lastHud=now; val copy=snapshot(); post { onHud?.invoke(copy) } }
                if(s.choices.isNotEmpty() && !choiceShown) { choiceShown=true; val cards=s.choices.toList(); post { onChoice?.invoke(cards) } }
                if(s.time-lastSave>=5) { lastSave=s.time; repository.save(s) }
                if(s.ended && !reportedEnd) { reportedEnd=true; repository.save(s); val copy=snapshot(); post { onFinished?.invoke(copy) } }
                render()
            }
            Thread.sleep(8)
        }
    }
    private fun render() {
        if(!holder.surface.isValid) return
        val c=holder.lockCanvas() ?: return
        try {
            c.drawColor(Color.BLACK)
            val scale=min(width/1920f,height/1080f)
            c.translate((width-1920*scale)/2,(height-1080*scale)/2); c.scale(scale,scale)
            if(shake>0 && store.isShakeEnabled()) c.translate((sin(engine.state.time*90)*shake*25).toFloat(),0f)
            c.drawBitmap(background,null,RectF(0f,0f,1920f,1080f),null)
            val s=engine.state
            paint.color=0xAA111826.toInt(); c.drawRect(0f,0f,1920f,115f,paint)
            paint.color=0xFF63DAD3.toInt(); paint.strokeWidth=3f; c.drawLine(235f,130f,235f,950f,paint)
            s.enemies.forEach { e ->
                val size=if(e.kind==5) 360f else if(e.kind==2) 250f else 190f
                val x=e.x.toFloat(); val y=e.y.toFloat()
                paint.colorFilter=if(e.flash>0) LightingColorFilter(Color.WHITE,0x888888) else null
                c.drawBitmap(sprites[e.kind],null,RectF(x-size/2,y-size/2,x+size/2,y+size/2),paint); paint.colorFilter=null
                paint.color=0xCC111111.toInt(); c.drawRect(x-size*.3f,y-size*.48f,x+size*.3f,y-size*.48f+8,paint)
                paint.color=if(e.kind==5) 0xFFFF824A.toInt() else 0xFF71DED0.toInt()
                c.drawRect(x-size*.3f,y-size*.48f,x-size*.3f+size*.6f*(e.hp/e.maxHp).coerceIn(0.0,1.0).toFloat(),y-size*.48f+8,paint)
                if((e.kind==3 && e.age%5<3) || (e.kind==5 && e.age%12>=8)) {
                    paint.color=0x8867C8FF.toInt(); paint.style=Paint.Style.STROKE; paint.strokeWidth=6f; c.drawCircle(x,y,size*.44f,paint); paint.style=Paint.Style.FILL
                }
                if(e.kind==5 && e.age%12<2) {
                    paint.color=0x55FF4D32; c.drawRect(240f,y-70,x,y+70,paint)
                    paint.color=Color.WHITE; paint.textSize=28f; c.drawText(context.getString(R.string.boss_warning),x-160,y-size*.6f,paint)
                }
                if(e.chill>0) { paint.color=0x8855CCFF.toInt(); c.drawCircle(x,y+size*.4f,18f,paint) }
                if(e.burn>0) { paint.color=0xFFFFAB40.toInt(); c.drawCircle(x+35,y+size*.3f,14f,paint) }
            }
            s.bolts.forEach { b ->
                paint.color=if(b.shock) 0xFF6BFFFF.toInt() else if(s.power>0) 0xFFFFB45E.toInt() else Color.WHITE
                paint.strokeWidth=if(b.shock) 16f else 6f
                c.drawLine(b.x.toFloat(),b.y.toFloat(),(b.x-cos(b.angle)*75).toFloat(),(b.y-sin(b.angle)*75).toFloat(),paint)
            }
            s.sparks.forEach { paint.color=0xFFFFB85A.toInt(); paint.alpha=(it.life/.4*255).toInt().coerceIn(0,255); c.drawCircle(it.x.toFloat(),it.y.toFloat(),6f,paint) }; paint.alpha=255
            c.save(); c.translate(150f,540f); c.rotate(Math.toDegrees(engine.aim).toFloat()); c.drawBitmap(bow,null,RectF(-240f,-240f,240f,240f),null); c.restore()
            if(s.combo>1) { paint.color=0xFFFFD573.toInt(); paint.textSize=40f; c.drawText("${s.combo} COMBO",800f,155f,paint) }
        } finally { holder.unlockCanvasAndPost(c) }
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val scale=min(width/1920f,height/1080f)
        val x=(event.x-(width-1920*scale)/2)/scale; val y=(event.y-(height-1080*scale)/2)/scale
        val pressed=event.actionMasked==MotionEvent.ACTION_DOWN || event.actionMasked==MotionEvent.ACTION_MOVE
        command { it.aim=atan2((y-540).toDouble(),(x-250).toDouble()).coerceIn(-1.2,1.2); it.aiming=pressed }
        if(event.actionMasked==MotionEvent.ACTION_UP) performClick()
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
