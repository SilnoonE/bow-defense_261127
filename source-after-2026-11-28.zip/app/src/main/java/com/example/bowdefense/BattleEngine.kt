package com.example.bowdefense

import java.io.Serializable
import java.util.UUID
import kotlin.math.*

/** Pure deterministic simulation. All times are active simulation seconds. */
data class Enemy(val id: Int, val kind: Int, var x: Double, var y: Double,
    var hp: Double, val maxHp: Double, var age: Double = 0.0,
    var chill: Double = 0.0, var burn: Double = 0.0, var stun: Double = 0.0,
    var flash: Double = 0.0, var summonAt: Double = 7.0) : Serializable
data class Bolt(var x: Double, var y: Double, val angle: Double, val damage: Double,
    var pierce: Int, val shock: Boolean = false, var counted: Boolean = false,
    val hitIds: MutableSet<Int> = mutableSetOf()) : Serializable
data class Spark(var x: Double, var y: Double, var life: Double, val color: Int) : Serializable
data class RunState(
    val sessionId: String = UUID.randomUUID().toString(), val createdAt: Long = System.currentTimeMillis(),
    var time: Double = 0.0, var waveTime: Double = 0.0, var wave: Int = 1, var aimAngle: Double = 0.0,
    var spawned: Int = 0, var spawnIn: Double = 1.0, var nextId: Int = 1,
    var hp: Int = 10, var score: Int = 0, var kills: Int = 0, var shots: Int = 0,
    var hits: Int = 0, var gold: Int = 0, var lowHpTime: Double = 0.0,
    var lowHpAchieved: Boolean = false, var power: Double = 0.0, var slow: Double = 0.0,
    var fireIn: Double = 0.0, var shockIn: Double = 0.0, var shockUses: Int = 0,
    var nextChoice: Double = 25.0, var firstChoiceAt: Double = -1.0,
    var combo: Int = 0, var comboTime: Double = 0.0, var bestCombo: Int = 0,
    var ended: Boolean = false, var cleared: Boolean = false, var continued: Boolean = false, var abandoned: Boolean = false,
    var deathKind: Int = -1, var archetype: Int = 0, var endless: Boolean = false,
    var bowMultiplier: Double = 1.0, var seed: Long = 183749L,
    var previousBest: Int = 0, var potionUses: Int = 0, var powerUses: Int = 0, var slowUses: Int = 0,
    var goldSpent: Int = 0, var purchases: Int = 0,
    val levels: IntArray = IntArray(12), val choices: MutableList<Int> = mutableListOf(),
    val enemies: MutableList<Enemy> = mutableListOf(), val bolts: MutableList<Bolt> = mutableListOf(),
    val sparks: MutableList<Spark> = mutableListOf()
) : Serializable

class BattleEngine(val state: RunState = RunState()) {
    var aiming = false
    var aim: Double
        get() = state.aimAngle
        set(value) { state.aimAngle = value }
    var shotEvent = false
    var hitEvent = false
    var killEvent = false
    var hurtEvent = false
    private var accumulator = 0.0
    private fun random(): Double {
        state.seed = (state.seed * 1664525L + 1013904223L) and 0xffffffffL
        return state.seed.toDouble() / 4294967296.0
    }
    fun advance(seconds: Double) {
        if (state.ended || state.choices.isNotEmpty()) { accumulator = 0.0; return }
        accumulator += seconds.coerceIn(0.0, 0.25)
        while (accumulator + 1e-9 >= STEP) {
            accumulator -= STEP
            tick(STEP)
            if (state.ended || state.choices.isNotEmpty()) { accumulator = 0.0; break }
        }
    }
    fun availableCards(): List<Int> = (0..11).filter { id ->
        state.levels[id] < (if (id % 3 == 2) 1 else 3) &&
            (id % 3 != 2 || (state.levels[id - 2] >= 2 && state.levels[id - 1] >= 1))
    }
    private fun offerChoice() {
        val pool = availableCards().toMutableList()
        repeat(min(3, pool.size)) { state.choices.add(pool.removeAt((random() * pool.size).toInt())) }
    }
    fun choose(id: Int): Boolean {
        if (id !in state.choices) return false
        state.levels[id]++
        state.choices.clear()
        if (state.firstChoiceAt < 0) state.firstChoiceAt = state.time
        return true
    }
    fun damage(): Double = (1.5 + (state.wave - 1) * 0.42 + state.levels[1] * 0.5) *
        (if (state.power > 0) 1.5 else 1.0) * (if (state.archetype == 1) 1.3 else 1.0) * (1 + max(0,state.levels[10]-1)*.1)
    fun cooldown(): Double = (0.5 * state.bowMultiplier * (1 - state.levels[9] * 0.10) *
        (if (state.archetype == 0) 0.85 else 1.0) * (if (state.levels[11] > 0) 0.65 else 1.0)).coerceAtLeast(0.16)
    fun shock(): Boolean {
        if (state.ended || state.choices.isNotEmpty() || state.shockIn > 0) return false
        state.shockIn = 20.0; state.shockUses++
        state.bolts.add(Bolt(250.0, 540.0, aim, damage() * 5, 50, true))
        state.shots++; shotEvent = true
        return true
    }
    fun revive(): Boolean {
        if (!state.ended || state.cleared || state.continued) return false
        state.hp = 10; state.ended = false; state.continued = true
        state.enemies.forEach { it.x = max(650.0, it.x); it.stun = 2.0 }
        return true
    }
    private fun spawn(kind: Int, x: Double = 1820.0, y: Double = 180 + random() * 620) {
        val base = doubleArrayOf(4.0, 2.8, 13.0, 8.0, 10.0, 190.0)[kind]
        val hp = base * (1 + (state.wave - 1) * 0.14)
        state.enemies.add(Enemy(state.nextId++, kind, x, y, hp, hp))
    }
    private fun tick(dt: Double) {
        val s = state
        s.time += dt; s.waveTime += dt
        s.power = max(0.0, s.power - dt); s.slow = max(0.0, s.slow - dt)
        s.shockIn = max(0.0, s.shockIn - dt); s.fireIn -= dt
        if (s.hp in 1..3) { s.lowHpTime += dt; if (s.lowHpTime >= 30) s.lowHpAchieved = true }
        else s.lowHpTime = 0.0
        s.comboTime -= dt; if (s.comboTime <= 0) s.combo = 0
        if (s.time >= s.nextChoice) { s.nextChoice += 32; offerChoice(); if (s.choices.isNotEmpty()) return }
        val budget = if (s.wave == 8 && !s.endless) 1 else 8 + s.wave * 2
        s.spawnIn -= dt
        if (s.spawned < budget && s.spawnIn <= 0 && s.enemies.size < 18) {
            val kind = if (s.wave == 8 && !s.endless) 5 else if (s.wave == 4 && s.spawned == 0) 2
                else { val r = random(); when { s.wave >= 5 && r < .16 -> 4; s.wave >= 3 && r < .35 -> 3; r < .55 -> 1; r > .85 -> 2; else -> 0 } }
            spawn(kind)
            if (s.wave == 4 && s.spawned == 0) { val e = s.enemies.last(); e.hp *= 2; s.enemies[s.enemies.lastIndex] = e.copy(maxHp = e.hp) }
            s.spawned++; s.spawnIn = (28.0 / budget).coerceAtLeast(0.9)
        }
        if (aiming && s.fireIn <= 0) {
            val count = if (s.levels[10] > 0) 2 else 1
            repeat(count) { i ->
                val angle = aim + if (count == 2) (i * 2 - 1) * .045 else 0.0
                s.bolts.add(Bolt(250.0, 540.0, angle, damage(), s.levels[0] + if (s.archetype == 1) 1 else 0))
                s.shots++
            }
            s.fireIn = cooldown(); shotEvent = true
        }
        val additions = mutableListOf<Pair<Double, Double>>()
        for (e in s.enemies.toList()) {
            e.age += dt; e.flash = max(0.0, e.flash - dt)
            e.stun = max(0.0, e.stun - dt); e.chill = max(0.0, e.chill - dt)
            if (e.burn > 0) { e.burn -= dt; e.hp -= dt * (0.8 + s.levels[6] * .6 + s.levels[8]) }
            var speed = doubleArrayOf(85.0, 145.0, 48.0, 65.0, 55.0, 0.0)[e.kind] * (1 + (s.wave - 1) * .025)
            if (e.kind == 5) {
                val phase = e.age % 12
                // 0–2 windup, 2–4 charge, 4–8 exposed, 8–12 armored recovery.
                speed = when { e.x > 1350 && phase < 2 -> 240.0; phase in 2.0..4.0 -> 620.0; phase >= 8 && e.x < 1350 -> -280.0; else -> 0.0 }
                if (e.age >= e.summonAt && s.enemies.size < 16) { additions.add(Pair(e.x, e.y)); e.summonAt += 12 }
            } else if (e.kind == 4 && e.age >= e.summonAt && s.enemies.size < 16) {
                additions.add(Pair(e.x + 60, e.y)); e.summonAt += 8
            }
            if (e.stun <= 0) e.x -= speed * dt * (if (s.slow > 0 || e.chill > 0) .5 else 1.0)
            if (e.x < 240) {
                s.hp = max(0, s.hp - if (e.kind == 5) 3 else if (e.kind == 2) 2 else 1)
                hurtEvent = true; s.deathKind = e.kind
                if (e.kind == 5) { e.x = 1000.0; e.age = 8.0 } else s.enemies.remove(e)
                if (s.hp == 0) { s.ended = true; return }
            }
        }
        additions.forEach { spawn(0, it.first, it.second.coerceIn(180.0, 800.0)) }
        for (b in s.bolts.toList()) {
            val oldX = b.x; val oldY = b.y
            b.x += cos(b.angle) * 1500 * dt; b.y += sin(b.angle) * 1500 * dt
            for (e in s.enemies.toList()) {
                if (e.id in b.hitIds || e.hp <= 0) continue
                val radius = if (e.kind == 5) 125.0 else if (e.kind == 2) 85.0 else 62.0
                if (distanceToSegment(e.x, e.y, oldX, oldY, b.x, b.y) > radius) continue
                b.hitIds.add(e.id)
                if (!b.counted) { s.hits++; b.counted = true }
                hitEvent = true; e.flash = .12
                val shield = (e.kind == 3 && e.age % 5 < 3) || (e.kind == 5 && e.age % 12 >= 8)
                var hit = b.damage * if (shield && !b.shock && s.levels[2] == 0) .35 else 1.0
                if (e.kind == 5 && (e.age % 12 in 4.0..8.0 || e.stun > 0)) hit *= 1.7
                e.hp -= hit
                if (s.levels[3] > 0 || s.archetype == 2) e.chill = 1.0 + s.levels[3]*.5 + s.levels[4]
                if (s.levels[5] > 0) e.stun = .35
                if (s.levels[6] > 0) e.burn = 2.0 + s.levels[7]
                if (b.shock) { e.stun = 2.0; e.x = min(1800.0, e.x + 130) }
                if (b.pierce-- <= 0) { s.bolts.remove(b); break }
            }
            if (b.x > 2000 || b.x < 0 || b.y < 70 || b.y > 1000) s.bolts.remove(b)
        }
        for (e in s.enemies.filter { it.hp <= 0 }) {
            s.enemies.remove(e); s.kills++; killEvent = true
            s.combo++; s.comboTime = 3.0; s.bestCombo = max(s.bestCombo, s.combo)
            val points = intArrayOf(10,20,50,30,40,500)[e.kind]
            s.score += points; s.gold += max(1, points / 5)
            repeat(6) { s.sparks.add(Spark(e.x + (random() - .5) * 100, e.y + (random() - .5) * 100, .4, e.kind)) }
            if (s.levels[8] > 0) s.enemies.filter { hypot(it.x-e.x,it.y-e.y)<180 }.forEach { it.burn = 3.0 }
        }
        s.sparks.forEach { it.life -= dt; it.y -= dt * 65 }; s.sparks.removeAll { it.life <= 0 }
        if (s.spawned >= budget && s.enemies.isEmpty() && s.waveTime >= 30) {
            if (s.wave == 8 && !s.endless) { s.cleared = true; s.ended = true; s.gold += 150 }
            else { s.wave++; s.waveTime = 0.0; s.spawned = 0; s.spawnIn = 2.0; s.hp = min(10, s.hp + 1); offerChoice() }
        }
    }
    companion object {
        const val STEP = 1.0 / 60.0
        fun distanceToSegment(x: Double, y: Double, ax: Double, ay: Double, bx: Double, by: Double): Double {
            val dx = bx-ax; val dy = by-ay
            val t = if (dx*dx+dy*dy == 0.0) 0.0 else (((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy)).coerceIn(0.0,1.0)
            return hypot(x-ax-t*dx,y-ay-t*dy)
        }
    }
}
