package com.example.bowdefense
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import kotlinx.coroutines.runBlocking
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class PersistenceTest {
    private val context=InstrumentationRegistry.getInstrumentation().targetContext
    @Test fun migrationPreservesLegacyRecordsAndAchievements() = runBlocking {
        val name="migration-test-${UUID.randomUUID()}"
        val old=context.openOrCreateDatabase(name,0,null)
        old.execSQL("CREATE TABLE IF NOT EXISTS `game_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `playDate` INTEGER NOT NULL, `survivalTimeSeconds` INTEGER NOT NULL, `score` INTEGER NOT NULL, `killCount` INTEGER NOT NULL, `arrowsShot` INTEGER NOT NULL, `hitCount` INTEGER NOT NULL, `accuracy` REAL NOT NULL, `goldEarned` INTEGER NOT NULL, `goldSpent` INTEGER NOT NULL, `shopPurchaseCount` INTEGER NOT NULL, `bowChangeCount` INTEGER NOT NULL, `maxStage` INTEGER NOT NULL, `maxWave` INTEGER NOT NULL, `resultType` TEXT NOT NULL, `isLowHpSurvivalAchieved` INTEGER NOT NULL)")
        old.execSQL("CREATE TABLE IF NOT EXISTS `achievements` (`id` INTEGER NOT NULL, `name` TEXT NOT NULL, `description` TEXT NOT NULL, `category` TEXT NOT NULL, `targetValue` INTEGER NOT NULL, `currentValue` INTEGER NOT NULL, `rewardGold` INTEGER NOT NULL, `isUnlocked` INTEGER NOT NULL, `isRewardClaimed` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        old.execSQL("CREATE TABLE IF NOT EXISTS `player_stats` (`id` INTEGER NOT NULL, `totalPlayCount` INTEGER NOT NULL, `totalKills` INTEGER NOT NULL, `totalArrowsShot` INTEGER NOT NULL, `totalHitCount` INTEGER NOT NULL, `totalGoldEarned` INTEGER NOT NULL, `totalGoldSpent` INTEGER NOT NULL, `totalSurvivalTime` INTEGER NOT NULL, `maxScore` INTEGER NOT NULL, `maxStage` INTEGER NOT NULL, `maxWave` INTEGER NOT NULL, `totalShopVisits` INTEGER NOT NULL, `totalShopPurchases` INTEGER NOT NULL, `ownedBowsCount` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        old.execSQL("INSERT INTO game_records VALUES(1,1234,60,800,20,40,30,75,80,10,1,0,2,1,'DEAD',1)")
        old.execSQL("INSERT INTO achievements VALUES(1,'legacy','preserve','test',1,1,50,1,1)")
        old.execSQL("INSERT INTO player_stats VALUES(1,7,99,100,90,500,20,600,800,2,3,4,5,3)")
        old.version=1; old.close()
        val db=AppDatabase.create(context,name)
        try {
            val rows=db.gameDao().getAllRecords()
            assertEquals(1,rows.size); assertEquals(800,rows[0].score); assertNull(rows[0].sessionId)
            val stats=db.gameDao().getPlayerStats()!!
            assertEquals(7,stats.totalPlayCount); assertEquals(3,stats.ownedBowsCount); assertEquals(0,stats.supplyCounted)
            val cursor=db.openHelper.readableDatabase.query("SELECT isRewardClaimed FROM achievements WHERE id=1")
            cursor.use { assertTrue(it.moveToFirst()); assertEquals(1,it.getInt(0)) }
        } finally { db.close(); context.deleteDatabase(name) }
    }
    @Test fun repeatedAndContinuedResultsAggregateOnlyDeltas() = runBlocking {
        val name="ledger-test-${UUID.randomUUID()}"
        val db=AppDatabase.create(context,name)
        val prefs="ledger-prefs-${UUID.randomUUID()}"
        val store=PurchaseStore(context,prefs)
        val manager=DataManager(context,db,store)
        try {
            val s=RunState(time=60.0,kills=10,shots=30,hits=20,gold=50,score=100,ended=true)
            val record=RunFinalizer.record(s)
            manager.saveGameRecord(record); manager.saveGameRecord(record)
            manager.saveGameRecord(record.copy(survivalTimeSeconds=90,killCount=15,score=150,goldEarned=80))
            val stats=db.gameDao().getPlayerStats()!!
            assertEquals(1,stats.totalPlayCount); assertEquals(15,stats.totalKills)
            assertEquals(80,stats.totalGoldEarned); assertEquals(90,stats.totalSurvivalTime)
            assertEquals(1,db.gameDao().getAllRecords().size)
            store.commitRunGold(s.sessionId,50); store.commitRunGold(s.sessionId,50); store.commitRunGold(s.sessionId,80)
            assertEquals(80,store.getGold())
            store.awardOnce("a",10); store.awardOnce("a",10); assertEquals(90,store.getGold())
            store.addLives(1); assertTrue(store.reserveContinue(s.sessionId)); assertTrue(store.reserveContinue(s.sessionId)); assertEquals(0,store.getLifeCount())
            assertTrue(store.buySupply("item_potion",60)); assertFalse(store.buySupply("item_power",90)); assertEquals(30,store.getGold())
            manager.refreshShopAchievements(); manager.refreshShopAchievements()
            assertEquals(1,db.gameDao().getPlayerStats()!!.totalShopPurchases)
            assertEquals(60,db.gameDao().getPlayerStats()!!.totalGoldSpent)
        } finally { db.close(); context.deleteDatabase(name); context.getSharedPreferences(prefs,0).edit().clear().commit() }
    }
}
